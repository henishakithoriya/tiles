<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Admin_model extends CI_Model {

		public function get_data($table,$fields = array())
		{
			if(!empty($fields))
			{
				$columns = implode("','",$fields);
				return $this->db->select($columns)->order_by("id","DESC")->get($table)->result_array();
			} else {
				return $this->db->order_by("id","DESC")->get($table)->result_array();
			}
		}

		public function get_row_data($timestamp,$table)
		{
			return $this->db->where("createdAt",$timestamp)->get($table)->row_array();
		}

		public function get_data_by_id($id,$table)
		{
			return $this->db->where("id",$id)->get($table)->row_array();	
		}

		public function insert_data($table,$data)
		{
			if($this->db->insert($table,$data))
				return $this->db->insert_id();
			else 
				return 0; 
		}

		public function update_data($id,$table,$data)
		{
			if($this->db->where('id',$id)->update($table,$data))
				return $this->db->affected_rows();
			else 
				return 0; 	
		}

		public function remove_data($id,$table)
		{
			if($this->db->where('id',$id)->delete($table))
				return $this->db->affected_rows();
			else 
				return 0; 	
		}

		public function get_quotations($flag,$status = 1)
		{
			$this->db->select("s.name AS customer_name,qm.id,qm.netAmt,qm.grossAmt,qm.discountPerc,qm.discountAmt,qm.createdAt,qm.date,qm.status,qm.isMakeInvoice");
			$this->db->from("quotation_master qm");
			$this->db->join("suppliers s","s.id=qm.salerId","left");
			$this->db->where("qm.isOrder",$flag);
			$this->db->where("qm.status",$status);
			$this->db->order_by("qm.id","DESC");
			$result = $this->db->get()->result_array();
			return $result;
		}

		public function get_stockIns()
		{
			$this->db->select("p.name AS product_name,ps.name AS product_size,s.name AS supplier_name,si.id,si.type,si.quantity,si.netAmt,si.date,si.time,si.createdAt");
			$this->db->from("stock_in si");
			$this->db->join("products p","si.productId=p.id","left");
			$this->db->join("product_sizes ps","p.pSize=ps.id","left");
			$this->db->join("suppliers s","si.supplierId=s.id","left");
			$this->db->order_by("si.id","DESC");
			$result = $this->db->get()->result_array();
			return $result;
		}

		public function get_stocks()
		{
			$this->db->select("p.id,p.name,p.createdAt,s.stocks");
			$this->db->from("products p");
			$this->db->join("stocks s","p.id=s.productId","left");
			$this->db->order_by("p.id","DESC");
			$result = $this->db->get()->result_array();
			return $result;
		}

		public function getId_from_timestamp($timestamp,$table,$fields = array())
		{
			if(!empty($fields))
			{
				$columns = implode(",",$fields);
				$this->db->select($columns);
			}
			$this->db->where("createdAt",$timestamp);
			$row = $this->db->get($table)->row_array();
			return $row;
		}

		public function get_product_timeline($productId)
		{
			$this->db->select('p.id,p.note,p.createdAt,p.createdAt');
			$this->db->where('p.productId',$productId);
			$result = $this->db->get("product_activities p")->result_array();
			return $result;
		}

		public function quotation_invoice($timestamp)
		{
			$this->db->select("p.name AS product_name,p.amount,q.salerId,q.type,q.vat,q.quantity,q.netAmt,q.date,q.time,q.note,q.status,q.isRetailer");
			$this->db->from("quotations q");
			$this->db->join("products p","q.productId=p.id","left");
			$this->db->where('q.createdAt',$timestamp);
			$row = $this->db->get()->row_array();
			return $row;
		}

		public function stockout_invoice($timestamp)
		{
			$this->db->select("p.name AS product_name,p.amount,so.salerId,so.type,so.vat,so.quantity,so.netAmt,so.date,so.time,so.note,so.isRetailer");
			$this->db->from("stock_out so");
			$this->db->join("products p","so.productId=p.id","left");
			$this->db->where('so.createdAt',$timestamp);
			$row = $this->db->get()->row_array();
			return $row;
		}

		public function get_saler_info($id,$table)
		{
			$this->db->select("id,name,email,phone,address");
			$this->db->where('id',$id);
			$row = $this->db->get($table)->row_array();
			return $row;
		}

		public function update_stock($productId,$data)
		{
			if($this->db->where('productId',$productId)->update("stocks",$data))
				return $this->db->affected_rows();
			else 
				return 0;
		}

		public function remove_company_data($id,$table)
		{
			$this->db->where("iCompanyId",$id)->delete($table);
		}

		public function get_users()
		{
			$this->db->select("c.name as company_name,u.*");
			$this->db->from("users u");
			$this->db->join("companies c","u.iCompanyId=c.id","left");
			$this->db->where("u.iUserType","1");
			$this->db->order_by("u.id","DESC");
			$result = $this->db->get()->result_array();
			return $result;
		}

		public function get_user_roles($userId)
		{
			$this->db->select('role');
			$this->db->where('userId',$userId);
			$result = $this->db->get("user_roles")->result_array();
			return $result;
		}

		public function get_client($phone,$companyId)
		{
		   	$this->db->select('id');
			$this->db->where('phone',$phone);
			$this->db->where('iCompanyId',$companyId);
			$this->db->where_in("userType",array(2,3,4));
			$row = $this->db->get("suppliers")->row_array();
			return $row;
		}

		public function get_quotation_products($id)
		{
			$this->db->select("p.name as product_name,q.*");
			$this->db->from("quotations q");
			$this->db->join("products p","q.pId=p.id","left");
			$this->db->where('q.qmId',$id);
			$result = $this->db->get("")->result_array();
			return $result;
		}
		
		public function get_customers($flag = 0)
		{
			if($flag == 0)
		    	$this->db->where_in('userType',array(2,3,4));
		    else 
		    	$this->db->where('userType',1);

		    $this->db->order_by("id","DESC");
		    $result = $this->db->get("suppliers")->result_array();
		    return $result;
		}
		
		public function get_available_stock($pid,$wid,$lid)
		{
		    $this->db->select("id,quantity");
		    $this->db->where(array("productId" => $pid,"warehouseId" => $wid,"locationId" => $lid));
		    $row = $this->db->get("stock_transfers")->row_array();
		    return $row;
		}
		
		public function get_stock_transfers()
		{
		    $this->db->select("p.name AS product_name,w.name AS warehouse_name,l.name as location_name,st.id,st.quantity,st.date,st.createdAt");
		    $this->db->from("stock_transfers st");
		    $this->db->join("products p","st.productId=p.id","left");
		    $this->db->join("warehouses w","st.warehouseId=w.id","left");
		    $this->db->join("locations l","st.locationId=l.id","left");
		    $result = $this->db->get()->result_array();
		    return $result;
		}

		public function get_quotation_no($table)
		{
			$this->db->select("id");
			$this->db->order_by("id","DESC");
			$this->db->limit(1);
			$no = $this->db->get($table)->row_array();
			if(empty($no))
				return 1;
			else 
				return ((int) $no["id"]+1);
		}

		public function get_customer_info($name)
		{
			$result = $this->db->query("SELECT `name`,`phone`,`email`,`address`,`note`,`userType` FROM `suppliers` WHERE `name` LIKE '%".$name."%' AND (`userType` = 2 OR `userType` = 3 OR `userType` = 4)  ORDER BY `name` ASC")->result_array();
			return $result;
		}

		public function get_all_products()
		{
			$this->db->select("p.id,p.name,p.pQty,p.sMeter,ps.name AS size,sAmount1,sAmount2,sAmount3");
			$this->db->from("products p");
			$this->db->join("product_sizes ps","p.pSize=ps.id");
			$result = $this->db->get()->result_array();
			return $result;
		}

		public function get_types($type)
		{
			$this->db->where("type",$type);
			$this->db->order_by("id","DESC");
			$result = $this->db->get("product_types")->result_array();
			return $result;
		}
	}