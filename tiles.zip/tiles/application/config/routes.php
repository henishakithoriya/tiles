<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	$route['default_controller'] = 'auth';
	$route['404_override'] = '';
	$route['translate_uri_dashes'] = FALSE;

	$route['unauthorized'] = "auth/unauthorized";

	$route['check_auth'] = "auth/check_auth";
	$route['logout'] = "auth/logout";
	$route['dashboard'] = "admin/dashboard";
	$route['order_summary/(:any)'] = "admin/order_summary/$1";
	$route['remove_order_product'] = "admin/remove_order_product";
	$route['change_company'] = "admin/change_company";

	// Product
	$route['products'] = "product";
	$route['new_product'] = "product/create";
	$route['add_product'] = "product/store";
	$route['edit_product/(:any)'] = "product/edit/$1";
	$route['update_product'] = "product/update";
	$route['remove_product'] = "product/remove";
	$route['product_timeline/(:any)'] = "product/product_timeline/$1";
	$route['get_warehouse_locations'] = "product/get_warehouse_locations";

	// Warehouse
	$route['warehouses'] = "warehouse";
	$route['new_warehouse'] = "warehouse/create";
	$route['add_warehouse'] = "warehouse/store";
	$route['edit_warehouse/(:any)'] = "warehouse/edit/$1";
	$route['update_warehouse'] = "warehouse/update";
	$route['remove_warehouse'] = "warehouse/remove";

	// Supplier
	$route['suppliers'] = "supplier";
	$route['new_supplier'] = "supplier/create";
	$route['add_supplier'] = "supplier/store";
	$route['edit_supplier/(:any)'] = "supplier/edit/$1";
	$route['update_supplier'] = "supplier/update";
	$route['remove_supplier'] = "supplier/remove";
	$route['get_supplier_info'] = "supplier/info";
	$route['newly_supplier'] = "supplier/store";

	// Supplier
	$route['retailers'] = "retailer";
	$route['new_retailer'] = "retailer/create";
	$route['add_retailer'] = "retailer/store";
	$route['edit_retailer/(:any)'] = "retailer/edit/$1";
	$route['update_retailer'] = "retailer/update";
	$route['remove_retailer'] = "retailer/remove";
	$route['get_customer_info'] = "retailer/get_customer_info";
	$route['new_customer'] = "retailer/new_customer";

	// Wholesaller
	$route['wholesallers'] = "wholesaller";
	$route['new_wholesaller'] = "wholesaller/create";
	$route['add_wholesaller'] = "wholesaller/store";
	$route['edit_wholesaller/(:any)'] = "wholesaller/edit/$1";
	$route['update_wholesaller'] = "wholesaller/update";
	$route['remove_wholesaller'] = "wholesaller/remove";

	// Quotation
	$route['quotations'] = "quotation";
	$route['new_quotation'] = "quotation/create";
	$route['add_quotation'] = "quotation/store";
	$route['edit_quotation/(:any)'] = "quotation/edit/$1";
	$route['update_quotation'] = "quotation/update";
	$route['remove_quotation'] = "quotation/remove";
	$route['change_quatation_status'] = "quotation/change_quatation_status";
	$route['quotation_invoice/(:any)'] = "quotation/quotation_invoice/$1";
	$route['quotation_report/(:any)'] = "quotation/quotation_report/$1";
	$route['get_new_row'] = "quotation/get_new_row";
	$route['quotation_save_changes'] = "quotation/quotation_save_changes";
	$route['delivery_notes'] = "quotation/delivery_notes";
	$route['invoices'] = "quotation/invoices";
	$route['generate_delivery_note/(:any)'] = "quotation/generate_delivery_note/$1";

	// Wholesaller
	$route['stock_ins'] = "stockin";
	$route['new_stock_in'] = "stockin/create";
	$route['add_stock_in'] = "stockin/store";
	$route['edit_stock_in/(:any)'] = "stockin/edit/$1";
	$route['update_stock_in'] = "stockin/update";
	$route['remove_stock_in'] = "stockin/remove";

	// Quotation
	$route['stock_outs'] = "stockout";
	$route['new_stock_out'] = "stockout/create";
	$route['add_stock_out'] = "stockout/store";
	$route['edit_stock_out/(:any)'] = "stockout/edit/$1";
	$route['update_stock_out'] = "stockout/update";
	$route['remove_stock_out'] = "stockout/remove";
	$route['stockout_invoice/(:any)'] = "stockout/stockout_invoice/$1";

	// Company
	$route['companies'] = "company";
	$route['new_company'] = "company/create";
	$route['add_company'] = "company/store";
	$route['edit_company/(:any)'] = "company/edit/$1";
	$route['update_company'] = "company/update";
	$route['remove_company'] = "company/remove";

	// User
	$route['users'] = "user";
	$route['new_user'] = "user/create";
	$route['add_user'] = "user/store";
	$route['edit_user/(:any)'] = "user/edit/$1";
	$route['update_user'] = "user/update";
	$route['remove_user'] = "user/remove";

	// Product Types
	$route['product_types'] = "product_type";
	$route['new_product_type'] = "product_type/create";
	$route['add_product_type'] = "product_type/store";
	$route['edit_product_type/(:any)'] = "product_type/edit/$1";
	$route['update_product_type'] = "product_type/update";
	$route['remove_product_type'] = "product_type/remove";

	// Product Sizes
	$route['product_sizes'] = "product_size";
	$route['new_product_size'] = "product_size/create";
	$route['add_product_size'] = "product_size/store";
	$route['edit_product_size/(:any)'] = "product_size/edit/$1";
	$route['update_product_size'] = "product_size/update";
	$route['remove_product_size'] = "product_size/remove";

	// Expense Types
	$route['expense_types'] = "expense_type";
	$route['new_expense_type'] = "expense_type/create";
	$route['add_expense_type'] = "expense_type/store";
	$route['edit_expense_type/(:any)'] = "expense_type/edit/$1";
	$route['update_expense_type'] = "expense_type/update";
	$route['remove_expense_type'] = "expense_type/remove";

	// VAT
	$route['vats'] = "vat";
	$route['new_vat'] = "vat/create";
	$route['add_vat'] = "vat/store";
	$route['edit_vat/(:any)'] = "vat/edit/$1";
	$route['update_vat'] = "vat/update";
	$route['remove_vat'] = "vat/remove";

	// Expense
	$route['expenses'] = "expense";
	$route['new_expense'] = "expense/create";
	$route['add_expense'] = "expense/store";
	$route['edit_expense/(:any)'] = "expense/edit/$1";
	$route['update_expense'] = "expense/update";
	$route['remove_expense'] = "expense/remove";

	// Transfer
	$route['transfers'] = "transfer";
	$route['new_transfer'] = "transfer/create";
	$route['add_transfer'] = "transfer/store";
	$route['edit_transfer/(:any)'] = "transfer/edit/$1";
	$route['update_transfer'] = "transfer/update";
	$route['remove_transfer'] = "transfer/remove";
	$route['get_available_stock'] = "transfer/get_available_stock";

	// Enhacement
	$route['enhacements'] = "enhacement";
	$route['new_enhacement'] = "enhacement/create";
	$route['add_enhacement'] = "enhacement/store";
	$route['edit_enhacement/(:any)'] = "enhacement/edit/$1";
	$route['update_enhacement'] = "enhacement/update";
	$route['remove_enhacement'] = "enhacement/remove";

	// VAT
	$route['locations'] = "location";
	$route['new_location'] = "location/create";
	$route['add_location'] = "location/store";
	$route['edit_location/(:any)'] = "location/edit/$1";
	$route['update_location'] = "location/update";
	$route['remove_location'] = "location/remove";
	
	// Sales Report
	$route['sale_reports'] = "sale_report/index";
	$route['search_sales_report'] = "sale_report/search_sales_report";
	$route['make_sale_payment'] = "sale_report/make_sale_payment";
	$route['sale_payment_history'] = "sale_report/sale_payment_history";