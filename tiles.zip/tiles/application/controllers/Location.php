<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Location extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
		    else 
		        $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['locations'] = $this->admin_model->get_data("locations");

			$this->load->view('include/header');
			$this->load->view('locations',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['location'] = array();

			$this->load->view('include/header');
			$this->load->view('location',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['iCompanyId'] 	= remove_space($this->input->post('companyId'));
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("locations",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Location added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['location'] = $this->admin_model->get_row_data($timestamp,"locations");

			$this->load->view('include/header');
			$this->load->view('location',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			// $params['iCompanyId'] 	= remove_space($this->input->post('companyId'));
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"locations",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Location edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"locations");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Location removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}