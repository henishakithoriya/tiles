<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Admin extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
				$this->userdata = $this->session->userdata('userdata');
		}

		public function dashboard()
		{
			$data['products'] = $this->admin_model->get_stocks();

			$this->load->view('include/header');
			$this->load->view('dashboard',$data);
			$this->load->view('include/footer');
		}

		public function order_summary($timestamp)
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['quotation'] 	= $this->admin_model->get_row_data($timestamp,"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotation_products'] = $this->admin_model->get_quotation_products($data['quotation']['id']);
			$data['timestamp'] 			= $timestamp;

			$this->load->view('include/header');
			$this->load->view('order_summary',$data);
			$this->load->view('include/footer');
		}

		public function remove_order_product()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"quotations");
			if($response > 0)
			{
				$order = $this->db->select("discountPerc")->where("id",$this->input->post('orderId'))->get("quotation_master")->row_array();
				$carts = $this->db->select("netAmt")->where("qmId",$this->input->post('orderId'))->get("quotations")->result_array();
				if(!empty($carts))
				{
					$netAmt = 0;
					$disAmt = 0;
					$grsAmt = 0;
					foreach($carts as $cart)
					{
						$netAmt = $netAmt + $cart['netAmt'];
					}
					$disAmt = ($netAmt*$order["discountPerc"])/100;
					$grsAmt = $netAmt - $disAmt;
					$param["totalAmt"] 	= $netAmt;
					$param["netAmt"] 	= $netAmt;
					$param["discountAmt"] 	= $disAmt;
					$param["grossAmt"] 	= $grsAmt;
					$this->admin_model->update_data($this->input->post('orderId'),"quotation_master",$param);
					$status = 1;
				} else {
					$status = 2;
					$response = $this->admin_model->remove_data($this->input->post('orderId'),"quotation_master");		
				}
				$ret_arr['status'] = $status;
				$this->session->set_flashdata('message','Product removed from cart.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;	
		}

		public function change_company()
		{
			$response = $this->admin_model->update_data($this->userdata['id'],"users",array("iCompanyId" => $this->input->post('company_id')));
			if($response > 0)
				$ret_arr['status'] = 1;
			else 
				$ret_arr['status'] = 0;
			
			$company = $this->admin_model->get_data_by_id($this->input->post('company_id'),"companies");
			$this->session->set_userdata('company_symbol',$company['sign']);	
			$this->session->set_userdata('company_id',$this->input->post('company_id'));	
			echo json_encode($ret_arr);
			exit;
		}
		
		public function export_sale_report_excel($reportId)
		{
		    $this->load->library('excel');
		    $prestasi = $this->excel->setActiveSheetIndex(0);
		    $this->excel->getActiveSheet()->setTitle('Sale payment History');
		    
		    $headers = array('Sr. No','Amount','Payment Method','Payment Date');
        	$this->excel->getActiveSheet()->fromArray($headers);
	        $first_letter = PHPExcel_Cell::stringFromColumnIndex(0);
	        $last_letter = PHPExcel_Cell::stringFromColumnIndex(count($headers)-1);
	        $header_range = "{$first_letter}1:{$last_letter}1";
	        $this->excel->getActiveSheet()->getStyle($header_range)->getFont()->setBold(true);

	        foreach(range($first_letter,$last_letter) as $columnID) {
	            $this->excel->getActiveSheet()->getColumnDimension($columnID)
	                ->setAutoSize(true);
	        }
	        $history = $this->db->select('amt,pMethod,date')->where("saleReportId",$reportId)->get("sales_order_payment")->result_array();
	        $no = 0;
        	$rowexcel = 1;
        	$total = 0;
        	foreach($history as $key => $val)
	        {
	            $no++;
	            $rowexcel++;
	            $this->excel->getActiveSheet()->getStyle('A'.$rowexcel.':C'.$rowexcel);
	            $this->excel->getActiveSheet()->getStyle('A'.$rowexcel.':C'.$rowexcel);
	            
	            $prestasi->setCellValue('A'.$rowexcel, $no);                        
	            $prestasi->setCellValue('B'.$rowexcel, $this->session->userdata('company_symbol')." ".$val['amt']);                        
	            $prestasi->setCellValue('C'.$rowexcel, getPaymentMethod($val['pMethod']));
	            $prestasi->setCellValue('D'.$rowexcel, formatDate($val['date'],6));
	        }
	        $filename = time().'.xlsx';
	        if (ob_get_contents())
	            ob_end_clean();
	            
	        header('Content-Type: application/vnd.ms-excel'); //mime type
	        header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
	        header('Cache-Control: max-age=0'); //no cache

	        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel2007');
	        $objWriter->save('php://output');
		}
		
		public function export_sale_report_pdf($reportId)
		{
		    $this->load->helper('pdf_helper');
		    $data['history'] = $this->db->select('amt,pMethod,date')->where("saleReportId",$reportId)->get("sales_order_payment")->result_array();
		    $this->load->view('export_sale_report_payment_history_pdf',$data);
		}
	}
