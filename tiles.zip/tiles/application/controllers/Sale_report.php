<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Sale_report extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
		    $data['list'] = $this->admin_model->get_customers(1);
            $this->load->view('include/header');
			$this->load->view('sale_reports',$data);
			$this->load->view('include/footer');
		}
		
		public function search_sales_report()
		{
		    $sdate = formatDate(str_replace("/", "-", $this->input->post('sdate')),5);
		    $edate = formatDate(str_replace("/", "-", $this->input->post('edate')),5);
		    
		    $this->db->where("clientId",$this->input->post('client'));
		    $this->db->where("orderDate BETWEEN '".$sdate."' AND '".$edate."'");
		    $data['orders'] = $this->db->get("sales_report")->result_array();
		    $data['client'] = $this->input->post('client_name');
	        $this->load->view('sales_orders',$data);    
		}
		
		public function make_sale_payment()
		{
		    $pending_amt = $this->input->post('pendingAmt') - $this->input->post('paid_amt');
		    $this->admin_model->update_data($this->input->post('reportId'),"sales_report",array("pAmt" => $pending_amt <= 0 ? 0 : $pending_amt));
		    
		    $params['saleReportId'] = $this->input->post('reportId');
			$params['amt']          = $this->input->post('paid_amt');
			$params['pMethod']      = $this->input->post('paid_method');
			$params['date']         = formatDate(str_replace("/", "-", $this->input->post('paidDate')),5);
		    $params['iCompanyId']   = get_user_company($this->userdata['id']);
			$params['createdBy']    = $this->userdata['id'];
			$params['updatedBy']    = 0;
			$params['createdAt']    = lastSeen();
			$params['updatedAt']    = "";	
			$response = $this->admin_model->insert_data("sales_order_payment",$params);
            
            $ret_arr['status'] = $response > 0 ? 1 : 0;
            $ret_arr['message'] = $response > 0 ? "Payment added successfully" : "Oops something went wrong please try again later";
			echo json_encode($ret_arr);
			exit;
		}
		
		public function sale_payment_history()
		{
		    $data['history'] = $this->db->where("saleReportId",$this->input->post('reportId'))->get("sales_order_payment")->result_array();
		    if(empty($data['history']))
		    {
		        $ret_arr['status']  = 0;
		    } else {
		        $ret_arr['status']  = 1;
		        $ret_arr['html']    = $this->load->view('sale_payment_history',$data,true);
		    }
		    echo json_encode($ret_arr);
		    exit;
		}
	}
