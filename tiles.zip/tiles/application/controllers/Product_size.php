<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Product_size extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['product_sizes'] = $this->admin_model->get_data("product_sizes");

			$this->load->view('include/header');
			$this->load->view('product_sizes',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['product_size'] = array();

			$this->load->view('include/header');
			$this->load->view('product_size',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$name = remove_space($this->input->post('snumber'))."x".remove_space($this->input->post('enumber'));
			$params['name'] 		= $name;
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("product_sizes",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Product Size added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['product_size'] = $this->admin_model->get_row_data($timestamp,"product_sizes");

			$this->load->view('include/header');
			$this->load->view('product_size',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$name = remove_space($this->input->post('snumber'))."x".remove_space($this->input->post('enumber'));
			$params['name'] 		= $name;
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"product_sizes",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Product Size edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"product_sizes");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Product Size removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}