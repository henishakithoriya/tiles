<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Company extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
			{
				redirect("auth");	
			} else {
				$this->userdata = $this->session->userdata('userdata');
				if($this->userdata['iUserType'] == 1)
				{
					redirect('unauthorized');
				}
			}
		}

		public function index()
		{
			$data['companies'] = $this->admin_model->get_data('companies');

			$this->load->view('include/header');
			$this->load->view('companies',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['company'] = array();

			$this->load->view('include/header');
			$this->load->view('company',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$photo = "";
			if($_FILES['company_logo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['encrypt_name'] = true;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('company_logo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				} 
			}
			$params['name'] 		= remove_space($this->input->post('company_name'));
			$params['country'] 		= remove_space($this->input->post('country'));
			$params['sign'] 	= remove_space($this->input->post('currency'));
			$params['address'] 		= remove_space($this->input->post('address'));
			$params['email'] 		= remove_space($this->input->post('email'));
			$params['phone'] 		= remove_space($this->input->post('phone'));
			$params['logo'] 		= $photo;
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("companies",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Company added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['company'] = $this->admin_model->get_row_data($timestamp,"companies");

			$this->load->view('include/header');
			$this->load->view('company',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$photo = $this->input->post('old_photo');
			if($_FILES['company_logo']['name'] != "")
			{
				$photo = "";
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['encrypt_name'] = true;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('company_logo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				}
				unlink(base_url()."assets/uploads/".$this->input->post('old_photo')); 
			}
			$params['name'] 		= remove_space($this->input->post('company_name'));
			$params['country'] 		= remove_space($this->input->post('country'));
			$params['sign'] 		= remove_space($this->input->post('currency'));
			$params['address'] 		= remove_space($this->input->post('address'));
			$params['email'] 		= remove_space($this->input->post('email'));
			$params['phone'] 		= remove_space($this->input->post('phone'));
			$params['logo'] 		= $photo;
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"companies",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Company edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"companies");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Company removed successfully.');
				remove_company_data($this->input->post('id'),"products");
				remove_company_data($this->input->post('id'),"product_activities");
				remove_company_data($this->input->post('id'),"quotations");
				remove_company_data($this->input->post('id'),"retailers");
				remove_company_data($this->input->post('id'),"stocks");
				remove_company_data($this->input->post('id'),"stock_in");
				remove_company_data($this->input->post('id'),"stock_out");
				remove_company_data($this->input->post('id'),"suppliers");
				remove_company_data($this->input->post('id'),"users");
				remove_company_data($this->input->post('id'),"user_roles");
				remove_company_data($this->input->post('id'),"warehouses");
				remove_company_data($this->input->post('id'),"wholesallers");
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}