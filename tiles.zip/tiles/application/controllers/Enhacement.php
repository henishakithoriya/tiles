<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Enhacement extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
			{
				redirect("auth");	
			} else {
				$this->userdata = $this->session->userdata('userdata');
			}
		}

		public function index()
		{
			$data['enhacements'] = $this->admin_model->get_data("stock_enhacements");
			$data['products'] = $this->admin_model->get_data("products");

			$this->load->view('include/header');
			$this->load->view('enhacements',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['enhacement'] = array();
			$data['products'] = $this->admin_model->get_data("products");

			$this->load->view('include/header');
			$this->load->view('enhacement',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$date = str_replace("/", "-", $this->input->post('enhacement_date'));
			$params['productId']		= remove_space($this->input->post('productId'));
			$params['quantity']			= remove_space($this->input->post('quantity'));
			$params['note']				= remove_space($this->input->post('enhacement_note'));
			$params['date']				= formatDate($date,5);
			$params['iCompanyId'] 		= $this->input->post('companyId');
			$params['createdBy'] 		= $this->userdata['id'];
			$params['updatedBy'] 		= 0;
			$params['createdAt'] 		= lastSeen();
			$params['updatedAt'] 		= "";
			$response = $this->admin_model->insert_data("stock_enhacements",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock Enhacement added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['enhacement'] = $this->admin_model->get_row_data($timestamp,"stock_enhacements");
			$data['products'] = $this->admin_model->get_data("products");

			$this->load->view('include/header');
			$this->load->view('enhacement',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$date = str_replace("/", "-", $this->input->post('enhacement_date'));
			$params['productId']		= remove_space($this->input->post('productId'));
			$params['quantity']			= remove_space($this->input->post('quantity'));
			$params['note']				= remove_space($this->input->post('enhacement_note'));
			$params['date']				= formatDate($date,5);
			$params['updatedBy']		= $this->userdata['id'];
			$params['updatedAt']		= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"stock_enhacements",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock Enhacement edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"stock_enhacements");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock Enhacement removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}