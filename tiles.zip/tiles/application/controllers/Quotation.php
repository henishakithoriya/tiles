<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Quotation extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['flag'] = 0;
			$data['quotations'] = $this->admin_model->get_quotations("N",0);

			$this->load->view('include/header');
			$this->load->view('quotations',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] = $products;
			$data['vats'] = $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] = array_reverse($data['vats']);
			$data['quotation'] = array();
			$data['qtyNo'] = $this->admin_model->get_quotation_no("quotation_master");

			$this->load->view('include/header');
			$this->load->view('quotation',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$client = $this->admin_model->get_client(trim($this->input->post('client_phone')),$this->input->post('companyId'));
			if(empty($client))
			{
				$client_params['name'] 			= trim($this->input->post('client_name'));
				$client_params['email'] 		= trim($this->input->post('client_email'));
				$client_params['phone']	 		= trim($this->input->post('client_phone'));
				$client_params['address'] 		= trim($this->input->post('client_address'));
				$client_params['note'] 			= trim($this->input->post('client_note'));
				$client_params['userType'] 		= $this->input->post('client_type') == "" ? 4 : $this->input->post('client_type');
				$client_params['photo'] 		= "";
				$client_params['iCompanyId'] 	= $this->input->post('companyId');
				$client_params['createdBy']		= $this->userdata['id'];
				$client_params['updatedBy'] 	= 0;
				$client_params['createdAt'] 	= lastSeen();
				$client_params['updatedAt'] 	= "";
				$clientId = $this->admin_model->insert_data("suppliers",$client_params);
			} else {
				$clientId = $client["id"];
			}
			$date = str_replace("/", "-", $this->input->post('date'));

			$params['salerId'] 		= $clientId;
			$params['totalAmt'] 	= remove_space($this->input->post('total_amt'));
			$params['netAmt'] 		= remove_space($this->input->post('net_amt'));
			$params['profit'] 		= remove_space($this->input->post('profit_perc'));
			$params['discountPerc'] = remove_space($this->input->post('discount_perc'));
			$params['discountAmt'] 	= remove_space($this->input->post('discount_amt'));
			$params['grossAmt'] 	= remove_space($this->input->post('gross_amt'));
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['vatNo'] 		= remove_space($this->input->post('vat_no'));
			$params['note'] 		= $this->input->post('note');
			$params['status'] 		= 0;
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['isOrder'] 		= "N";
			$params['iOrderFrom'] 	= 0;
			$params['isMakeInvoice']= "N";
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("quotation_master",$params);
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$child_params = array();
				for($i = 0; $i < count($_POST['product']); $i++)
				{
					if($_POST['product'][$i] != "")
					{
						$temp['pId'] 		= $_POST['product'][$i];
						$temp['pSize'] 		= $_POST['psize'][$i];
						$temp['pType'] 		= 0;
						$temp['pSqMt'] 		= $_POST['sq_mt'][$i];
						$temp['pPrice'] 	= $_POST['product_price'][$i];
						$temp['quantity'] 	= $_POST['quantity'][$i];
						$temp['productAmt'] = $_POST['product_amt'][$i];
						$temp['vatPerc'] 	= $_POST['vatId'][$i];
						$temp['vatAmt'] 	= $_POST['vatAmt'][$i];
						$temp['netAmt'] 	= $_POST['netAmt'][$i];
						$temp['qmId'] 		= $response;
						$temp['iCompanyId'] = $this->input->post('companyId');
						$temp['createdBy'] 	= $this->userdata['id'];
						$temp['updatedBy'] 	= 0;
						$temp['createdAt'] 	= lastSeen();
						$temp['updatedAt'] 	= "";
						$child_params[] = $temp;
					}
				}
				if(!empty($child_params))
				{
					$this->db->insert_batch("quotations",$child_params);
				}
				$this->session->set_flashdata('message','Quotation added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data["generate"] = 0;
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['quotation'] 	= $this->admin_model->get_row_data($timestamp,"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotations'] = $this->admin_model->get_quotation_products($data['quotation']['id']);

			if($data['quotation']['status'] == 0)
			{
				$this->load->view('include/header');
				$this->load->view('edit_quotation',$data);
				$this->load->view('include/footer');
			}
		}

		public function update()
		{
			$client = $this->admin_model->get_client(trim($this->input->post('client_phone')),$this->input->post('companyId'));
			if(empty($client))
			{
				$client_params['name'] 			= trim($this->input->post('client_name'));
				$client_params['email'] 		= trim($this->input->post('client_email'));
				$client_params['phone']	 		= trim($this->input->post('client_phone'));
				$client_params['address'] 		= trim($this->input->post('client_address'));
				$client_params['note'] 			= trim($this->input->post('client_note'));
				$client_params['userType'] 		= $this->input->post('client_type') == "" ? 4 : $this->input->post('client_type');
				$client_params['photo'] 		= "";
				$client_params['iCompanyId'] 	= $this->input->post('companyId');
				$client_params['createdBy']		= $this->userdata['id'];
				$client_params['updatedBy'] 	= 0;
				$client_params['createdAt'] 	= lastSeen();
				$client_params['updatedAt'] 	= "";
				$clientId = $this->admin_model->insert_data("suppliers",$client_params);
			} else {
				$clientId = $client["id"];
			}
			$date = str_replace("/", "-", $this->input->post('date'));

			$params['salerId'] 		= $clientId;
			$params['totalAmt'] 	= remove_space($this->input->post('total_amt'));
			$params['netAmt'] 		= remove_space($this->input->post('net_amt'));
			$params['profit'] 		= remove_space($this->input->post('profit_perc'));
			$params['discountPerc'] = remove_space($this->input->post('discount_perc'));
			$params['discountAmt'] 	= remove_space($this->input->post('discount_amt'));
			$params['grossAmt'] 	= remove_space($this->input->post('gross_amt'));
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['vatNo'] 		= remove_space($this->input->post('vat_no'));
			$params['note'] 		= $this->input->post('note');
			$params['isMakeInvoice']= $this->input->post('generate') == 0 ? "N" : $this->input->post('make_invoice');
			$params['status']		= $this->input->post('generate');
			$params['updatedBy'] 	= $this->userdata['id'];
			$params['updatedAt'] 	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"quotation_master",$params);
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$child_params = array();
				for($i = 0; $i < count($_POST['product']); $i++)
				{
					if($_POST['product'][$i] != "")
					{
						$temp['pId'] 		= $_POST['product'][$i];
						$temp['pSize'] 		= $_POST['psize'][$i];
						$temp['pType'] 		= 0;
						$temp['pSqMt'] 		= $_POST['sq_mt'][$i];
						$temp['pPrice'] 	= $_POST['product_price'][$i];
						$temp['quantity'] 	= $_POST['quantity'][$i];
						$temp['productAmt'] = $_POST['product_amt'][$i];
						$temp['vatPerc'] 	= $_POST['vatId'][$i];
						$temp['vatAmt'] 	= $_POST['vatAmt'][$i];
						$temp['netAmt'] 	= $_POST['netAmt'][$i];
						$temp['qmId'] 		= $this->input->post('uid');
						$temp['iCompanyId'] = $this->input->post('companyId');
						$temp['createdBy'] 	= $this->userdata['id'];
						$temp['updatedBy'] 	= 0;
						$temp['createdAt'] 	= lastSeen();
						$temp['updatedAt'] 	= "";
						$child_params[] = $temp;
					}
				}
				if(!empty($child_params))
				{
					$this->db->where('qmId',$this->input->post('uid'))->delete("quotations");
					$this->db->insert_batch("quotations",$child_params);
				}
				$this->session->set_flashdata('message','Quotation edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"quotation_master");
			if($response > 0)
			{
				$this->db->where('qmId',$this->input->post('id'))->delete("quotations");
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Quotation removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function change_quatation_status()
		{
			$order = $this->db->select('id,salerId,totalAmt,grossAmt,orderDate,iCompanyId')->where('id',$this->input->post('qstatus'))->get("quotation_master")->row_array();

			$params['status'] 		= $this->input->post('change_status');
			if($this->input->post('change_status') == 1) {
				$params['isOrder'] 	= "Y";
				
				// add entry in sales_report
				$sales_params['orderId']    = $order['id'];
				$sales_params['clientId']   = $order['salerId'];
				$sales_params['tAmt']       = $order['grossAmt'];
				$sales_params['pAmt']       = $order['grossAmt'];
				$sales_params['flag']       = "N";
				$sales_params['orderDate']  = formatDate("",3);
			    $sales_params['iCompanyId'] = $order['iCompanyId'];
    			$sales_params['createdBy'] 	= $this->userdata['id'];
    			$sales_params['updatedBy'] 	= 0;
    			$sales_params['createdAt'] 	= lastSeen();
    			$sales_params['updatedAt'] 	= "";	
    			$this->admin_model->insert_data("sales_report",$sales_params);
			}
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			if($order['orderDate'] == "")
				$params['orderDate']	= lastSeen();

			$response = $this->admin_model->update_data($this->input->post('qstatus'),"quotation_master",$params);
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Status updated successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			if($this->input->post('page') == "quotation")
				redirect('quotations');
			else 
				redirect('stock_outs');
		}

		public function quotation_invoice($timestamp)
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['users'] 			    = $this->admin_model->get_data('users',array('id,fname,lname'));
			$data['quotation'] 	= $this->admin_model->get_row_data($timestamp,"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotation_products'] = $this->admin_model->get_quotation_products($data['quotation']['id']);

			if($data['quotation']['isMakeInvoice'] == "Y")
			{
				$this->load->view('include/header');
				$this->load->view('print_invoice',$data);
				$this->load->view('include/footer');
			}
		}

		public function get_new_row()
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data['products'] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['no']			= $this->input->post('no');
			$data['vats'] 		= array_reverse($data['vats']);
			$this->load->view('new_row',$data);
		}

		public function quotation_save_changes()
		{
			$order = $this->admin_model->get_row_data($this->input->post('timestamp'),"quotation_master");
			
			$params['totalAmt'] = $this->input->post('total');
			if($order['profit'] > 0)
				$params['grossAmt'] = $this->input->post('total') + $order['profit'];	
			else 
				$params['grossAmt'] = $this->input->post('total') - $order['profit'];	

			$response = $this->admin_model->update_data($order['id'],"quotation_master",$params);

			$this->db->update_batch('quotations', $_POST['carts'], 'id');
			$this->session->set_flashdata('message','Cart updated successfully.');
			echo json_encode(array("status" => 1));
		}

		public function delivery_notes()
		{
			$data['flag'] = 1;
			$data['quotations'] = $this->admin_model->get_quotations("N",0);

			$this->load->view('include/header');
			$this->load->view('quotations',$data);
			$this->load->view('include/footer');
		}
		
		public function invoices()
		{
			$data['flag'] = 2;
			$data['quotations'] = $this->admin_model->get_quotations("N",1);

			$this->load->view('include/header');
			$this->load->view('quotations',$data);
			$this->load->view('include/footer');
		}

		public function generate_delivery_note($timestamp)
		{
			$data["generate"] = 1;
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['quotation'] 	= $this->admin_model->get_row_data($timestamp,"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotations'] = $this->admin_model->get_quotation_products($data['quotation']['id']);

			$this->load->view('include/header');
			$this->load->view('edit_quotation',$data);
			$this->load->view('include/footer');
		}
		
		public function quotation_report($timestamp)
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['users'] 			    = $this->admin_model->get_data('users',array('id,fname,lname'));
			$data['quotation'] 	= $this->admin_model->get_row_data($timestamp,"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotation_products'] = $this->admin_model->get_quotation_products($data['quotation']['id']);

			$this->load->view('include/header');
			$this->load->view('quotation_report',$data);
			$this->load->view('include/footer');
		}
		
		public function send_quotation_pdf()
		{
		    $products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] 	= $products;
			$data['vats'] 		= $this->admin_model->get_data('vats',array('id,name'));
			$data['vats'] 		= array_reverse($data['vats']);
			$data['users'] 	    = $this->admin_model->get_data('users',array('id,fname,lname'));
			$data['quotation'] 	= $this->admin_model->get_row_data($this->input->post('pdf_supplier_timestamp'),"quotation_master");
			$data['client'] 	= $this->admin_model->get_data_by_id($data['quotation']['salerId'],"suppliers");
			$data['quotation_products'] = $this->admin_model->get_quotation_products($data['quotation']['id']);
			$data["logo"] = base_url()."assets/images/logo.png";
			$data["currency"] = $this->session->userdata('company_symbol');
			$data["email_to"] = $this->input->post('henishakithoriya@gmail.com');
			
			$data["html"] = $this->load->view('quotation_pdf',$data,true);
			$data["qno"]  = $data['quotation']['id'];
			$data["temp_qno"]  = $this->input->post('pdf_supplier_timestamp');
			$data["customer_name"]  = $this->input->post('pdf_supplier_name');
			$data["customer_mail"]  = $this->input->post('pdf_supplier_mail');
			$this->load->view("send_quotation_mail",$data);
		}
	}