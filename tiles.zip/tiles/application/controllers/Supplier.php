<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Supplier extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['suppliers'] = $this->admin_model->get_customers(1);

			$this->load->view('include/header');
			$this->load->view('suppliers',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['supplier'] = array();

			$this->load->view('include/header');
			$this->load->view('supplier',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$photo = "";
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['encrypt_name'] = true;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('photo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				} 
			}
			$params['name'] 	= remove_space($this->input->post('name'));
			$params['email'] 	= remove_space($this->input->post('email'));
			$params['phone'] 	= remove_space($this->input->post('phone'));
			$params['address'] 	= remove_space($this->input->post('address'));
			$params['photo'] 	= $photo;
			$params['userType'] 	= 1;
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("suppliers",$params);

			if($response > 0)
			{
				$ret_arr['status'] = $response;
				$this->session->set_flashdata('message','Supplier added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['supplier'] = $this->admin_model->get_row_data($timestamp,"suppliers");

			$this->load->view('include/header');
			$this->load->view('supplier',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$photo = $this->input->post('old_photo');
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['encrypt_name'] = true;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('photo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				}
				unlink(base_url()."assets/uploads/".$this->input->post('old_photo')); 
			}
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['email'] 		= remove_space($this->input->post('email'));
			$params['phone'] 		= remove_space($this->input->post('phone'));
			$params['address'] 		= remove_space($this->input->post('address'));
			$params['photo'] 		= $photo;
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"suppliers",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Supplier edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$supplier = $this->admin_model->get_data_by_id($this->input->post('id'),"suppliers");
			if(!empty($supplier))
			{
				unlink(base_url()."assets/uploads/".$supplier['photo']); 

				$response = $this->admin_model->remove_data($this->input->post('id'),"suppliers");
				if($response > 0)
				{
					$ret_arr['status'] = 1;
					$this->session->set_flashdata('message','Supplier removed successfully.');
				} else {
					$ret_arr['status'] = 0;
					$this->session->set_flashdata('message','Oops something went wrong please try again later.');
				} 
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Supplier not found.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function info()
		{
			$supplier = $this->admin_model->get_data_by_id($this->input->post('supplier_id'),"suppliers");
			if(empty($supplier))
			{
				$ret_arr['status'] 	= 0;
			} else {
				$ret_arr['status'] 	= 1;
				$ret_arr['phone'] 	= $supplier['phone'];
				$ret_arr['email'] 	= $supplier['email'];
			}
			echo json_encode($ret_arr);
			exit;
		}
	}