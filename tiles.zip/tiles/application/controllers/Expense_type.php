<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Expense_type extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
			{
				redirect("auth");	
			} else {
				$this->userdata = $this->session->userdata('userdata');
				if($this->userdata['iUserType'] == 1)
				{
					redirect('unauthorized');
				}
			}
		}

		public function index()
		{
			$data['expense_types'] = $this->admin_model->get_types(1);

			$this->load->view('include/header');
			$this->load->view('expense_types',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['expense_type'] = array();

			$this->load->view('include/header');
			$this->load->view('expense_type',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['type'] 		= 1;
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("product_types",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Expense Type added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['expense_type'] = $this->admin_model->get_row_data($timestamp,"product_types");

			$this->load->view('include/header');
			$this->load->view('expense_type',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"product_types",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Expense Type edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"product_types");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Expense Type removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}