<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Transfer extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['transfers']  = $this->admin_model->get_stock_transfers();

			$this->load->view('include/header');
			$this->load->view('transfers',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['transfer'] = array();
			$data['products'] = $this->admin_model->get_data("products",array("id,name"));
			$data['warehouses'] = $this->admin_model->get_data("warehouses",array("id,name"));

			$this->load->view('include/header');
			$this->load->view('transfer',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
		    $date = str_replace("/", "-", $this->input->post('transfer_date'));
		    $oldStock = $this->admin_model->get_available_stock($this->input->post('productId'),$this->input->post('warehouseId'),$this->input->post('locationId'));
		    $newStock = $this->admin_model->get_available_stock($this->input->post('productId'),$this->input->post('newWarehouseId'),$this->input->post('newLocationId'));
		    if(!empty($oldStock)) 
		    {
		        $stock_minus = (int) $oldStock['quantity'] - (int) $this->input->post('traQuantity');
		        if($stock_minus == 0)
		        {
		            $response = $this->admin_model->remove_data($oldStock['id'],"stock_transfers");        
		        } else {
		            $response = $this->admin_model->update_data($oldStock['id'],"stock_transfers",array("quantity" => $stock_minus));        
		        }
		    }
		    if(!empty($newStock))
		    {
		        $stock_plus = (int) $newStock['quantity'] + (int) $this->input->post('traQuantity');
		        $params['quantity'] = $stock_plus;
		        $params['note']     = remove_space($this->input->post('note'));
    			$params['date']	    = formatDate($date,5);
    			$params['updatedBy']= $this->userdata['id'];
    			$params['updatedAt']= lastSeen();
		        $response = $this->admin_model->update_data($newStock['id'],"stock_transfers",$params);
		    } else {
    			$params['productId']		= remove_space($this->input->post('productId'));
    			$params['warehouseId']		= remove_space($this->input->post('newWarehouseId'));
    			$params['locationId']		= remove_space($this->input->post('newLocationId'));
    			$params['quantity']			= remove_space($this->input->post('traQuantity'));
    			$params['note']				= remove_space($this->input->post('note'));
    			$params['date']				= formatDate($date,5);
    			$params['iCompanyId'] 		= $this->input->post('companyId');
    			$params['createdBy'] 		= $this->userdata['id'];
    			$params['updatedBy'] 		= 0;
    			$params['createdAt'] 		= lastSeen();
    			$params['updatedAt'] 		= "";
    			$response = $this->admin_model->insert_data("stock_transfers",$params);   
		    }
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock Transferred successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['transfer'] = $this->admin_model->get_row_data($timestamp,"stock_transfers");
			$data['products'] = $this->admin_model->get_data("products",array("id,name"));
			$data['warehouses'] = $this->admin_model->get_data("warehouses",array("id,name"));

			$this->load->view('include/header');
			$this->load->view('transfer',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"stock_transfers");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock Enhacement removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
		
		public function get_available_stock()
		{
		    $row = $this->admin_model->get_available_stock($this->input->post('productId'),$this->input->post('warehouseId'),$this->input->post('locationId'));
		    $ret_arr['status'] = empty($row) ? 0 : $row['quantity'];
		    echo json_encode($ret_arr);
		    exit;
		}
	}