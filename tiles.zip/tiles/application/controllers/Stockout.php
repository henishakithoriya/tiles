<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Stockout extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['stockouts'] = $this->admin_model->get_quotations("Y");
			$data['retailers'] = $this->admin_model->get_customers(0);

			$this->load->view('include/header');
			$this->load->view('stockouts',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] = $products;
			$data['retailers'] 		= $this->admin_model->get_customers(0);
			$data['vats'] = $this->admin_model->get_data('vats',array('id,name'));
			$data['stockout'] = array();

			$this->load->view('include/header');
			$this->load->view('stockout',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$client = $this->admin_model->get_client($this->input->post('wholesaller_retailer'),trim($this->input->post('client_phone')));
			if(empty($client))
			{
				$client_params['name'] 			= trim($this->input->post('client_name'));
				$client_params['email'] 		= trim($this->input->post('client_email'));
				$client_params['phone'] 		= trim($this->input->post('client_phone'));
				$client_params['address'] 		= trim($this->input->post('client_address'));
				$client_params['type'] 		    = $this->input->post('wholesaller_retailer') == 1 ? "Y" : "N";
				$client_params['photo'] 		= "";
				$client_params['iCompanyId'] 	= $this->input->post('companyId');
				$client_params['createdBy'] 	= $this->userdata['id'];
				$client_params['updatedBy'] 	= 0;
				$client_params['createdAt'] 	= lastSeen();
				$client_params['updatedAt'] 	= "";
				$clientId = $this->admin_model->insert_data("wholesallers",$client_params);
			} else {
				$clientId = $client["id"];
			}
			$date = str_replace("/", "-", $this->input->post('date'));

			$params['salerId'] 		= $clientId;
			$params['vatAmt'] 		= $this->input->post('vat_amt');
			$params['grossAmt'] 	= $this->input->post('gross_amt');
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['note'] 		= $this->input->post('note');
			$params['isRetailer'] 	= $this->input->post('wholesaller_retailer') == 2 ? "Y" : "N";
			$params['vatId'] 		= $this->input->post('vat');
			$params['status'] 		= 1;
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['isOrder'] 		= "Y";
			$params['iOrderFrom'] 	= 1;
			$params['orderDate'] 	= lastSeen();
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("quotation_master",$params);
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$child_params = array();
				for($i = 0; $i < count($_POST['product']); $i++)
				{
					if($_POST['product'][$i] != "")
					{
						$temp['productId'] 	= $_POST['product'][$i];
						$temp['type'] 		= $_POST['type'][$i];
						$temp['quantity'] 	= $_POST['quantity'][$i];
						$temp['productAmt'] = $_POST['product_price'][$i];
						$temp['netAmt'] 	= $_POST['product_amt'][$i];
						$temp['qmId'] 		= $response;
						$temp['iCompanyId'] = 0;
						$temp['createdBy'] 	= $this->userdata['id'];
						$temp['updatedBy'] 	= 0;
						$temp['createdAt'] 	= lastSeen();
						$temp['updatedAt'] 	= "";
						$child_params[] = $temp;
					}
				}
				if(!empty($child_params))
				{
					$this->db->insert_batch("quotations",$child_params);
				}
				$this->session->set_flashdata('message','Stock Out entry added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['products'] = $this->admin_model->get_data('products',array('id,name,amount'));
			$data['retailers'] 		= $this->admin_model->get_retailers('N');
			$data['wholesallers'] 	= $this->admin_model->get_retailers('Y');
			$data['stockout'] = $this->admin_model->get_row_data($timestamp,"stock_out");
			
			$this->load->view('include/header');
			$this->load->view('stockout',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$client = $this->admin_model->get_client($this->input->post('wholesaller_retailer'),trim($this->input->post('client_phone')));
			if(empty($client))
			{
				$client_params['name'] = trim($this->input->post('client_name'));
				$client_params['email'] = trim($this->input->post('client_email'));
				$client_params['phone'] = trim($this->input->post('client_phone'));
				$client_params['address'] = trim($this->input->post('client_address'));
				$client_params['type'] 		    = $this->input->post('wholesaller_retailer') == 1 ? "Y" : "N";
				$client_params['photo'] = "";
				$client_params['iCompanyId'] = 0;
				$client_params['createdBy'] 	= $this->userdata['id'];
				$client_params['updatedBy'] 	= 0;
				$client_params['createdAt'] 	= lastSeen();
				$client_params['updatedAt'] 	= "";
				$clientId = $this->admin_model->insert_data("wholesallers",$client_params);
			} else {
				$clientId = $client["id"];
			}
			$date = str_replace("/", "-", $this->input->post('date'));

			$params['salerId'] 		= $clientId;
			$params['vatAmt'] 		= $this->input->post('vat_amt');
			$params['grossAmt'] 	= $this->input->post('gross_amt');
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['note'] 		= $this->input->post('note');
			$params['isRetailer'] 	= $this->input->post('wholesaller_retailer') == 2 ? "Y" : "N";
			$params['vatId'] 		= $this->input->post('vat');
			$params['iCompanyId'] 	= 0;
			$params['updatedBy'] 	= $this->userdata['id'];
			$params['updatedAt'] 	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"quotation_master",$params);
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$child_params = array();
				for($i = 0; $i < count($_POST['product']); $i++)
				{
					if($_POST['product'][$i] != "")
					{
						$temp['productId'] 	= $_POST['product'][$i];
						$temp['type'] 		= $_POST['type'][$i];
						$temp['quantity'] 	= $_POST['quantity'][$i];
						$temp['productAmt'] = $_POST['product_price'][$i];
						$temp['netAmt'] 	= $_POST['product_amt'][$i];
						$temp['qmId'] 		= $this->input->post('uid');
						$temp['iCompanyId'] = 0;
						$temp['createdBy'] 	= $this->userdata['id'];
						$temp['updatedBy'] 	= 0;
						$temp['createdAt'] 	= lastSeen();
						$temp['updatedAt'] 	= "";
						$child_params[] = $temp;
					}
				}
				if(!empty($child_params))
				{
					$this->db->where('qmId',$this->input->post('uid'))->delete("quotations");
					$this->db->insert_batch("quotations",$child_params);
				}
				$this->session->set_flashdata('message','Stock Out entry edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"stock_out");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stockout entry removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function stockout_invoice($timestamp)
		{
			$data['invoice'] 	= $this->admin_model->stockout_invoice($timestamp);
			$data['invoice_no']	= $timestamp;
			if(!empty($data['invoice']))
			{
				if($data['invoice']['isRetailer'] == "Y")
				{
					$data['saler'] = $this->admin_model->get_saler_info($data['invoice']['salerId'],"retailers");
				} else {
					$data['saler'] = $this->admin_model->get_saler_info($data['invoice']['salerId'],"wholesallers");
				}
			} else {
				$data['saler'] = array();
			}

			$this->load->view('include/header');
			$this->load->view('print_invoice',$data);
			$this->load->view('include/footer');
		}
	}