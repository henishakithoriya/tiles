<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Product extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['products'] = $this->admin_model->get_data('products');
			$data['product_types'] = $this->admin_model->get_data('product_types');
			$data['product_sizes'] = $this->admin_model->get_data('product_sizes');
			
			$this->load->view('include/header');
			$this->load->view('products',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['product'] = array();
			$data['product_sizes'] = $this->admin_model->get_data('product_sizes');
			$data['product_types'] = $this->admin_model->get_data('product_types');

			$this->load->view('include/header');
			$this->load->view('product',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$photo = "";
			$timestamp = lastSeen(); 
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['file_name'] = $timestamp;
				$this->load->library('upload',$config);

				if($this->upload->do_upload("photo"))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				}
			}
			$params['name'] 		= strtoupper(remove_space($this->input->post('product_name')));
			$params['pType'] 		= $this->input->post('ptype');
			$params['pSize'] 		= $this->input->post('psize');
			$params['pQty'] 		= remove_space($this->input->post('product_qty'));
			$params['sMeter'] 		= $this->input->post('sq_meter');
			$params['pAmount'] 		= remove_space($this->input->post('pamount'));
			$params['sAmount1'] 	= remove_space($this->input->post('samount1'));
			$params['sAmount2'] 	= remove_space($this->input->post('samount2'));
			$params['sAmount3'] 	= remove_space($this->input->post('samount3'));
			$params['photo'] 		= $photo;
			$params['note'] 		= remove_space($this->input->post('product_note'));
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= $timestamp;
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("products",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Product added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['product'] = $this->admin_model->get_row_data($timestamp,"products");
			$data['product_sizes'] = $this->admin_model->get_data('product_sizes');
			$data['product_types'] = $this->admin_model->get_data('product_types');

			$this->load->view('include/header');
			$this->load->view('product',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$photo = $this->input->post("old_photo");
			$timestamp = lastSeen(); 
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['file_name'] = $timestamp;
				$this->load->library('upload',$config);

				if($this->upload->do_upload("photo"))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				}
			}
			$params['name'] 		= strtoupper(remove_space($this->input->post('product_name')));
			$params['pType'] 		= $this->input->post('ptype');
			$params['pSize'] 		= $this->input->post('psize');
			$params['pQty'] 		= remove_space($this->input->post('product_qty'));
			$params['sMeter'] 		= $this->input->post('sq_meter');
			$params['pAmount'] 		= remove_space($this->input->post('pamount'));
			$params['sAmount1'] 	= remove_space($this->input->post('samount1'));
			$params['sAmount2'] 	= remove_space($this->input->post('samount2'));
			$params['sAmount3'] 	= remove_space($this->input->post('samount3'));
			$params['photo'] 		= $photo;
			$params['note'] 		= remove_space($this->input->post('product_note'));
			$params['updatedBy'] 	= $this->userdata['id'];
			$params['updatedAt'] 	= $timestamp;
			$response = $this->admin_model->update_data($this->input->post('uid'),"products",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Product edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$product = $this->admin_model->get_data_by_id($this->input->post('id'),"products");
			if(!empty($product))
			{
				unlink(base_url()."assets/uploads/".$product['photo']); 

				$response = $this->admin_model->remove_data($this->input->post('id'),"products");
				if($response > 0)
				{
					$ret_arr['status'] = 1;
					$this->session->set_flashdata('message','Product removed successfully.');
				} else {
					$ret_arr['status'] = 0;
					$this->session->set_flashdata('message','Oops something went wrong please try again later.');
				} 
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Product not found.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function product_timeline($timestamp)
		{	
			$data['products'] = $this->admin_model->getId_from_timestamp($timestamp,"products",array("id,name"));
			$data['timeline'] = $this->admin_model->get_product_timeline($data['products']['id']);

			$this->load->view('include/header');
			$this->load->view('timeline',$data);
			$this->load->view('include/footer');
		}

		public function upload_product()
		{
			echo "<pre>";
			print_r ($_FILES);
		}

		public function get_warehouse_locations()
		{
			$warehouse = $this->admin_model->get_data_by_id($this->input->post('warehouseId'),"warehouses");
			$locations = $warehouse['location'];

			$ret_arr['status'] = 0;
			$ret_arr['html'] = "";
			if($locations != "")
			{
				$location_arr = explode(",", $locations);
				$this->db->select('id,name');
				$this->db->where_in('id',$location_arr);
				$this->db->where('iCompanyId',$this->input->post('companyId'));
				$result = $this->db->get("locations")->result_array();
				if(!empty($result))
				{
					$ret_arr['status'] = 1;
					$content = "";
					$content .= "<option value=''>Option</option>";
					foreach($result as $val)
					{
						if($val['id'] == $this->input->post('locationId'))
							$content .= "<option value='".$val['id']."' selected>".$val['name']."</option>";
						else 
							$content .= "<option value='".$val['id']."'>".$val['name']."</option>";
					}
					$ret_arr['html'] = $content;
				}		
			}
			echo json_encode($ret_arr);
			exit;
		}
		
		public function import_product()
		{
		    require_once APPPATH . "/third_party/PHPExcel.php";
            $inputFileName = "./assets/product_format.xlsx";
            
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
            $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
            $flag = true;
            $i = 0;
            foreach ($allDataInSheet as $value) {
                if($flag) {
                    $flag =false;
                    continue;
                }
                if($value['A'] != "")
                {
                    $product = strtoupper(trim($value['A']));
                    $product_type_nm = strtoupper(trim($value['B']));
                    $product_size_nm = strtoupper(trim($value['C']));
                    $checkProduct = $this->db->where("name",$product)->get("products")->num_rows();
                    
                    if($checkProduct == 0)
                    {
                        $inserdata = array();
                        $inserdata['name'] = $value['A'];
                        $product_type = $this->db->select("id")->where("name",$product_type_nm)->get("product_types")->row_array();
                        if(!empty($product_type))
                        {
                            $inserdata['pType'] = $product_type["id"];    
                        }
                        $product_size = $this->db->select("id")->where("name",$product_size_nm)->get("product_sizes")->row_array();
                        if(!empty($product_size))
                        {
                            $inserdata['pSize'] = $product_size["id"];    
                        }
                        $inserdata['pQty'] = $value['D'];
                        $inserdata['sMeter'] = $value['E'];        
                        $inserdata['pAmount'] = 0;        
                        $inserdata['sAmount1'] = 0;        
                        $inserdata['sAmount2'] = 0;        
                        $inserdata['sAmount3'] = 0;        
                        $inserdata['photo'] = "";        
                        $inserdata['note'] = "";        
                        $inserdata['iCompanyId'] = 2;        
                        $inserdata['createdBy'] = 1;        
                        $inserdata['updatedBy'] = 0;        
                        $inserdata['createdAt'] = lastSeen()."".$i;        
                        $inserdata['updatedAt'] = "";        
                        $this->db->insert("products",$inserdata);
                    }
                }
                $i++;
            }
		}
	}