<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Vat extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['vats'] = $this->admin_model->get_data("vats");

			$this->load->view('include/header');
			$this->load->view('vats',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['vat'] = array();

			$this->load->view('include/header');
			$this->load->view('new_vat',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("vats",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','VAT added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			redirect("vats");
		}

		public function edit($timestamp)
		{
			$data['vat'] = $this->admin_model->get_row_data($timestamp,"vats");

			$this->load->view('include/header');
			$this->load->view('new_vat',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"vats",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','VAT edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"vats");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','VAT removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}
	}