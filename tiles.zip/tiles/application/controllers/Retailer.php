<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Retailer extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['retailers'] = $this->admin_model->get_customers();

			$this->load->view('include/header');
			$this->load->view('retailers',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$data['retailer'] = array();

			$this->load->view('include/header');
			$this->load->view('retailer',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$photo = "";
			$timestamp = lastSeen();
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] = "./assets/uploads/";
				$config['allowed_types'] = "*";
				$config['file_name'] = $timestamp;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('photo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				} 
			}
			$params['name'] 	= remove_space($this->input->post('name'));
			$params['email'] 	= remove_space($this->input->post('email'));
			$params['phone'] 	= remove_space($this->input->post('phone'));
			$params['address'] 	= remove_space($this->input->post('address'));
			$params['note'] 	= remove_space($this->input->post('note'));
			$params['userType'] = $this->input->post('user_type');
			$params['photo'] 	= $photo;
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= $timestamp;
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("suppliers",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Customer added successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$data['retailer'] = $this->admin_model->get_row_data($timestamp,"suppliers");

			$this->load->view('include/header');
			$this->load->view('retailer',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$photo = $this->input->post('old_photo');
			$timestamp = lastSeen();
			if($_FILES['photo']['name'] != "")
			{
				$config['upload_path'] 		= "./assets/uploads/";
				$config['allowed_types'] 	= "*";
				$config['file_name'] 		= $timestamp;
				$this->load->library('upload',$config);

				if($this->upload->do_upload('photo'))
				{
					$photoArr = $this->upload->data();
					$photo = $photoArr['file_name'];
				}
				unlink(base_url()."assets/uploads/".$this->input->post('old_photo')); 
			}
			$params['name'] 		= remove_space($this->input->post('name'));
			$params['email'] 		= remove_space($this->input->post('email'));
			$params['phone'] 		= remove_space($this->input->post('phone'));
			$params['address'] 		= remove_space($this->input->post('address'));
			$params['note'] 		= remove_space($this->input->post('note'));
			$params['userType'] 	= $this->input->post('user_type');
			$params['photo'] 		= $photo;
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= $timestamp;
			$response = $this->admin_model->update_data($this->input->post('uid'),"suppliers",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Customer edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$retailer = $this->admin_model->get_data_by_id($this->input->post('id'),"suppliers");
			if(!empty($retailer))
			{
				unlink(base_url()."assets/uploads/".$retailer['photo']); 

				$response = $this->admin_model->remove_data($this->input->post('id'),"suppliers");
				if($response > 0)
				{
					$ret_arr['status'] = 1;
					$this->session->set_flashdata('message','Customer removed successfully.');
				} else {
					$ret_arr['status'] = 0;
					$this->session->set_flashdata('message','Oops something went wrong please try again later.');
				} 
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Customer not found.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function get_customer_info()
		{
			$data['customers'] = $this->admin_model->get_customer_info($this->input->post('name'));
			$html = $this->load->view('get_customer_info',$data,true);
			echo json_encode(array("html" => $html));
			exit;
		}

		public function new_customer()
		{
			$params['name'] 	= remove_space($_POST['customer_name']);
			$params['email'] 	= remove_space($_POST['customer_email']);
			$params['phone'] 	= remove_space($_POST['customer_phone']);
			$params['address'] 	= remove_space($_POST['customer_address']);
			$params['note'] 	= remove_space($_POST['customer_note']);
			$params['userType'] = $_POST['customer_type'];
			$params['photo'] 	= "";
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("suppliers",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
			} else {
				$ret_arr['status'] = 0;
			}
			echo json_encode($ret_arr);
			exit;
		}
	}