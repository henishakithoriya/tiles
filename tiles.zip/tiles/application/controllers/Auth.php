<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Auth extends CI_Controller {

		public function __construct(){
			parent::__construct();
		}

		public function index()
		{
			$data['companies'] = $this->admin_model->get_data("companies");
			
			$this->load->view('login',$data);
		}

		public function check_auth()
		{
			$company  = trim($this->input->post('company'));
			$username = trim($this->input->post('username'));
			$password = trim($this->input->post('password'));

			$this->db->where("(email = '".$username."' OR phone = '".$username."')");
			$this->db->where("iCompanyId",$company);
			$this->db->where("vPassword",md5($password));
			$response = $this->db->get("users")->row_array();
			
			if(empty($response))
			{
				$ret_arr['status'] 	= 0;
				$ret_arr['message'] = "Username or password is wrong"; 
			} else {
				$this->session->set_userdata('userdata',$response);
				$ret_arr['status']	= 1;
				$ret_arr['message']	= "Login successfully";
			}
			echo json_encode($ret_arr);
		}

		public function unauthorized()
		{
			$this->load->view('unauthorized');
		}
		
		public function logout()
		{
		    $this->session->sess_destroy();
		    redirect('auth');
		}
	}
