<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class Stockin extends CI_Controller {
		var $userdata;

		public function __construct(){
			parent::__construct();
			hide_errors();

			if($this->session->userdata('userdata') == false)
				redirect("auth");	
			else 
			    $this->userdata = $this->session->userdata('userdata');
		}

		public function index()
		{
			$data['stockins'] = $this->admin_model->get_stockIns();
			
			$this->load->view('include/header');
			$this->load->view('stock_ins',$data);
			$this->load->view('include/footer');
		}

		public function create()
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data["products"] = $products;
			$data['suppliers'] = $this->admin_model->get_customers(1);
			$data['warehouses'] = $this->admin_model->get_data('warehouses');
			$data['stockIn'] = array();
			$data['invoiceNo'] = $this->admin_model->get_quotation_no("stock_in");

			$this->load->view('include/header');
			$this->load->view('stock_in',$data);
			$this->load->view('include/footer');
		}

		public function store()
		{
			$date = str_replace("/", "-", $this->input->post('date'));
			$params['batch_no'] 	= $this->input->post('batch_no');
			$params['productId'] 	= $this->input->post('product');
			$params['supplierId'] 	= $this->input->post('supplier');
			$params['type'] 		= 0;
			$params['warehouseId']  = $this->input->post('warehouse');
			$params['locationId']   = $this->input->post('location');
			$params['quantity'] 	= $this->input->post('quantity');
			$params['netAmt'] 		= $this->input->post('net_amount');
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['note'] 		= $this->input->post('note');
			$params['isFullPaid'] 	= $this->input->post('paid_type');
			$params['iCompanyId'] 	= $this->input->post('companyId');
			$params['createdBy'] 	= $this->userdata['id'];
			$params['updatedBy'] 	= 0;
			$params['createdAt'] 	= lastSeen();
			$params['updatedAt'] 	= "";
			$response = $this->admin_model->insert_data("stock_in",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock In added successfully.');
				
				// Stock Calcultation
				$this->db->select("stocks");
				$this->db->where(array("productId" => $this->input->post('product'),"iCompanyId" => $this->input->post('companyId')));
				$old_stock = $this->db->get("stocks")->row_array();
				if(empty($old_stock)) {
				    $new_stock = $this->input->post('quantity');   
				    $stock_param['productId']   = $this->input->post('product');
				    $stock_param['stocks']      = $new_stock;
				    $stock_param['iCompanyId']  = $this->input->post('companyId');
				    $stock_param['createdBy']   = $this->userdata['id'];
				    $stock_param['updatedBy']   = 0;
				    $stock_param['createdAt']   = lastSeen();
				    $stock_param['updatedAt']   = "";
				    $this->admin_model->insert_data("stocks",$stock_param);
				} else {
				    $new_stock = $old_stock["stocks"] + $this->input->post('quantity');   
				    $this->admin_model->update_stock($this->input->post('product'),array("stocks" => $new_stock));
				} 
				
				// Stock Transfer
				$this->db->select("id,quantity");
				$this->db->where("iCompanyId",$this->input->post('companyId'));
				$this->db->where("productId",$this->input->post('product'));
				$this->db->where("warehouseId",$this->input->post('warehouse'));
				$this->db->where("locationId",$this->input->post('location'));
				$old_transfer = $this->db->get("stock_transfers")->row_array();
				if(empty($old_transfer))
				{
				    $new_stock = $this->input->post('quantity');   
				    $transfer_param['productId']    = $this->input->post('product');
				    $transfer_param['warehouseId']  = $this->input->post('warehouse');
				    $transfer_param['locationId']   = $this->input->post('location');
				    $transfer_param['quantity']     = $new_stock;
				    $transfer_param['note']         = "";
				    $transfer_param['date']         = date("Y-m-d H:i:s");
				    $transfer_param['iCompanyId']   = $this->input->post('companyId');
				    $transfer_param['createdBy']    = $this->userdata['id'];
				    $transfer_param['updatedBy']    = 0;
				    $transfer_param['createdAt']    = lastSeen();
				    $transfer_param['updatedAt']    = "";
				    $this->admin_model->insert_data("stock_transfers",$transfer_param);
				} else {
				    $new_stock = $old_transfer["quantity"] + $this->input->post('quantity'); 
				    $this->db->where("id",$old_transfer["id"])->update("stock_transfers",array("quantity" => $new_stock));
				}
				
				// Report
				$report_param['orderId']        = $response;
			    $report_param['clientId']       = $this->input->post('supplier');
			    $report_param['tAmt']           = $this->input->post('net_amount');
			    $report_param['pAmt']           = $this->input->post('net_amount');
			    $report_param['flag']           = "N";
			    $report_param['orderDate']      = date("Y-m-d H:i:s");
			    $report_param['iCompanyId']   = $this->input->post('companyId');
			    $report_param['createdBy']    = $this->userdata['id'];
			    $report_param['updatedBy']    = 0;
			    $report_param['createdAt']    = lastSeen();
			    $report_param['updatedAt']    = "";
			    $this->admin_model->insert_data("sales_report",$report_param);
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function edit($timestamp)
		{
			$products = $this->admin_model->get_all_products();
			if(!empty($products))
			{
				foreach($products as $key => $val)
				{
					$products[$key]['name'] = $val['name']."<small>(".$val['size'].")</small>";
				}
			}
			$data['products'] = $products;
			$data['suppliers'] = $this->admin_model->get_customers(1);
			$data['stockIn'] = $this->admin_model->get_row_data($timestamp,"stock_in");
			$data['warehouses'] = $this->admin_model->get_data('warehouses');
			$this->load->view('include/header');
			$this->load->view('stock_in',$data);
			$this->load->view('include/footer');
		}

		public function update()
		{
			$date = str_replace("/", "-", $this->input->post('date'));
			$params['batch_no'] 	= $this->input->post('batch_no');
			$params['productId'] 	= $this->input->post('product');
			$params['supplierId'] 	= $this->input->post('supplier');
			$params['warehouseId']  = $this->input->post('warehouse');
			$params['locationId']   = $this->input->post('location');
			$params['quantity'] 	= $this->input->post('quantity');
			$params['netAmt'] 		= $this->input->post('net_amount');
			$params['date'] 		= formatDate($date,5);
			$params['time'] 		= $this->input->post('time');
			$params['note'] 		= $this->input->post('note');
			$params['isFullPaid'] 	= $this->input->post('paid_type');
			$params['updatedBy'] 	= $this->userdata['id'];
			$params['updatedAt'] 	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('uid'),"stock_in",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock In edited successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function remove()
		{
			$response = $this->admin_model->remove_data($this->input->post('id'),"stock_in");
			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Stock In removed successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			echo json_encode($ret_arr);
			exit;
		}

		public function change_quatation_status()
		{
			$params['status'] 		= $this->input->post('change_status');
			$params['updatedBy']	= $this->userdata['id'];
			$params['updatedAt']	= formatDate("",1);
			$params['uTimestamp'] 	= lastSeen();
			$response = $this->admin_model->update_data($this->input->post('qstatus'),"quotations",$params);

			if($response > 0)
			{
				$ret_arr['status'] = 1;
				$this->session->set_flashdata('message','Status updated successfully.');
			} else {
				$ret_arr['status'] = 0;
				$this->session->set_flashdata('message','Oops something went wrong please try again later.');
			}
			redirect('quotations');
		}
	}