<?php 

	function hide_errors()
	{
		error_reporting(0);
	}

	function remove_space($str)
	{
		return trim($str);
	}

	function lastSeen()
	{
		return round(microtime(true)*1000);
	}

	function formatDate($date,$type)
	{
		switch($type)
		{
			case 1:
			$date = date("Y-m-d H:i:s");
			break;

			case 2:
			$date = date("d M, Y",strtotime($date));
			break;

			case 3:
			$date = date("Y-m-d");
			break;

			case 4:
			$date = date("d/m/Y");
			break;

			case 5:
			$date = date("Y-m-d",strtotime($date));
			break;

			case 6:
			$date = date("d/m/Y",strtotime($date));
			break;

			case 7:
			$date = date("h:i A",strtotime($date));
			break;

			case 8:
			$date = date("h:i",strtotime($date));
			break;
		}
		return $date;
	}

	function formatNumber($number,$type)
	{
		switch($type)
		{
			case 1:
			$number = number_format($number);
			break;
		}
		return $number;
	}

	function get_user_roles($userId,$userType)
	{
		$CI =&get_instance();	

		$roles = array();
		if($userType == 0)
		{
			$roles = array('suppliers','quotations','delivery_notes','invoices','customers','wholesallers','warehouses','products','stock_in','stock_out','product_types','product_sizes','vats','expense_types','expenses','stock_transfers','stock_enhacement','stock_transfer','locations');
		} else {
			$user_roles = $CI->admin_model->get_user_roles($userId);
			if(!empty($user_roles))
			{
				foreach($user_roles as $val)
				{
					$roles[] = $val['role'];	
				}
			}
		}
		return $roles;
	}

	function generateNo($table,$no)
	{
		switch ($table) {
			case 'quotation':
			$no = "Q".$no;
			break;
		}
		return $no;
	}

	function getCurrencySign($countryId)
	{
		$CI =&get_instance();

		$countrySign = $CI->db->select("sign")->where("id",$countryId)->get("companies")->row_array();
		if(empty($countrySign))
		{
			$symbol = "£"; 
		} else {
			$symbol = $countrySign['sign'];
		}
		return $symbol;
	}

	function get_companies()
	{
		$CI =&get_instance();

		$companies 	= $CI->db->order_by("id","DESC")->get("companies")->result_array();
		$ret_arr 	= array();

		if(!empty($companies))
			$ret_arr = $companies;

		return $ret_arr;
	}

	function get_user_company($user_id)
	{
		$CI =&get_instance();

		$company 	= $CI->db->select("iCompanyId")->where("id",$user_id)->get("users")->row_array();
		$ret_arr 	= empty($company) ? "" : $company['iCompanyId'];
		return $ret_arr;
	}
	
	function userInfo()
	{
	    $CI =&get_instance();
	    $userdata = $CI->session->userdata('userdata');
	    return $userdata;
	}
	
	function convertText($text,$type)
	{
	    switch($type)
	    {
	        case 1:
	        $text = ucfirst($text);
	        break;
	        
	        case 2:
	        $text = ucwords($text);
	        break;
	        
	        case 3:
	        $text = strtoupper($text);
	        break;
	    }
	    return $text;
	}
	
	function getPaymentMethod($method)
	{
	    $method_name = "Cash";
	    switch($val['pMethod'])
        {
            case 1:
            $method_name = "Cash";
            break;
            
            case 2:
            $method_name = "Online";
            break;
            
            case 3:
            $method_name = "Debit Card";
            break;
            
            case 4:
            $method_name = "Credit Card";
            break;
            
            case 5:
            $method_name = "Net Banking";
            break;
            
            case 6:
            $method_name = "Other";
            break;
        }
        return $method_name;
	}
	function bug_icon()
	{
		return "<span class='error'>*</span>";
	}
	function timepicker($start = 6,$end = 23,$duration = 5,$default = "")
	{
		$start 	= (int) $start;
		$end 	= (int) $end;

		$str = "";
		$no = 0;
		for($i = $start;$i <= $end; $i ++)
		{
			for($j = 0;$j <=59; $j = $j+$duration)
			{
				$no++;
				$show_time = date("h:i A",strtotime($i.":".$j.":00"));
				$hidden_time = date("H:i:s",strtotime($i.":".$j.":00"));
				$hidden_time_m = date("H:i",strtotime($i.":".$j));

				if($hidden_time == $default)
					$str .= "<option value=".$hidden_time." name='".$no."' selected>".$show_time."</option>";
				else 
					$str .= "<option value=".$hidden_time." name='".$no."'>".$show_time."</option>";
			}
		}
		return $str;
	}
	
	function send_email($subject,$body,$to)
	{
	    $CI = & get_instance();
	    
	    // $CI->load->library('email');    
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.gmail.com';
        $config['smtp_port']  = '586';
        $config['smtp_user'] = 'harrykithoriya007@gmail.com';
        $config['smtp_pass'] = 'vzblkxawkgjaavot';
        $config['mailtype'] = 'html';
        // $config['charset'] = 'iso-8859-1';
        $config['charset'] = 'utf-8';
        $config['wordwrap'] = TRUE;
        $config['newline'] = "\r\n";
        $CI->load->library("email",$config);
        // $CI->email->library("email",$config);
        $CI->email->set_newline("\r\n");
        $CI->email->from("harrykithoriya007@gmail.com","Prime Wholesaler");
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($body);
        if($CI->email->send())
            return "S";
        else 
            return "F";
	}